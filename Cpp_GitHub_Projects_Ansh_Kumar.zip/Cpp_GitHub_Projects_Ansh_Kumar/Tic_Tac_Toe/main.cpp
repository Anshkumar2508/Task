/*
 Project: Tic Tac Toe
 Author: ANSH KUMAR
 Admission No.: 24SCSE1040723
 Language: C++17
*/
#include <iostream>
#include <array>
#include <limits>
using namespace std;

void display(const array<char, 9>& b) {
    cout << "\n";
    for (int r = 0; r < 3; ++r) {
        cout << " ";
        for (int c = 0; c < 3; ++c) {
            int i = r * 3 + c;
            cout << (b[i] == ' ' ? char('1' + i) : b[i]);
            if (c < 2) cout << " | ";
        }
        cout << '\n';
        if (r < 2) cout << "---+---+---\n";
    }
    cout << '\n';
}
char winner(const array<char, 9>& b) {
    const int lines[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},
                             {1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    for (const auto& line : lines)
        if (b[line[0]] != ' ' && b[line[0]] == b[line[1]] && b[line[1]] == b[line[2]])
            return b[line[0]];
    return ' ';
}
int main() {
    cout << "===== TIC TAC TOE =====\n"
         << "Player 1: X | Player 2: O\n";
    char again;
    do {
        array<char, 9> board; board.fill(' ');
        char player = 'X', win = ' ';
        int moves = 0;
        while (moves < 9 && win == ' ') {
            display(board);
            int position;
            cout << "Player " << player << ", choose a position (1-9): ";
            if (!(cin >> position)) return 0;
            if (position < 1 || position > 9 || board[position - 1] != ' ') {
                cout << "Invalid or occupied position. Try again.\n"; continue;
            }
            board[position - 1] = player; ++moves;
            win = winner(board);
            player = (player == 'X' ? 'O' : 'X');
        }
        display(board);
        if (win != ' ') cout << "Congratulations! Player " << win << " wins!\n";
        else cout << "It's a draw!\n";
        cout << "Play again? (y/n): "; cin >> again;
    } while (again == 'y' || again == 'Y');
    cout << "Thanks for playing!\n";
    return 0;
}
