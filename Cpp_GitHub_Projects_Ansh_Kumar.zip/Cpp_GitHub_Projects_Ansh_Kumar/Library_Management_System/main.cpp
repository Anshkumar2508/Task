/*
 Project: Library Management System
 Author: ANSH KUMAR
 Admission No.: 24SCSE1040723
 Language: C++17
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <limits>
using namespace std;

struct Book { int id; string title, author; int available; };
const string FILE_NAME = "books.txt";

vector<Book> loadBooks() {
    vector<Book> books; ifstream in(FILE_NAME); Book b;
    while (in >> b.id >> quoted(b.title) >> quoted(b.author) >> b.available) books.push_back(b);
    return books;
}
void saveBooks(const vector<Book>& books) {
    ofstream out(FILE_NAME);
    for (const auto& b : books) out << b.id << ' ' << quoted(b.title) << ' '
        << quoted(b.author) << ' ' << b.available << '\n';
}
int main() {
    auto books = loadBooks(); int choice;
    do {
        cout << "\n===== LIBRARY MANAGEMENT SYSTEM =====\n"
             << "1. Add book\n2. Display books\n3. Search book by ID\n"
             << "4. Issue book\n5. Return book\n6. Delete book\n0. Exit\nChoice: ";
        if (!(cin >> choice)) return 0;
        if (choice == 1) {
            Book b; cout << "Book ID: "; cin >> b.id;
            if (any_of(books.begin(), books.end(), [&](const Book& x){ return x.id == b.id; })) {
                cout << "Book ID already exists.\n"; continue;
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Book title: "; getline(cin, b.title);
            cout << "Author: "; getline(cin, b.author);
            cout << "Number of copies: "; cin >> b.available;
            if (b.available < 0) { cout << "Invalid number of copies.\n"; continue; }
            books.push_back(b); saveBooks(books); cout << "Book added.\n";
        } else if (choice == 2) {
            if (books.empty()) cout << "No books found.\n";
            for (const auto& b : books)
                cout << "ID: " << b.id << " | " << b.title << " | " << b.author
                     << " | Available: " << b.available << '\n';
        } else if (choice >= 3 && choice <= 6) {
            int id; cout << "Book ID: "; cin >> id;
            auto it = find_if(books.begin(), books.end(), [&](const Book& b){ return b.id == id; });
            if (it == books.end()) { cout << "Book not found.\n"; continue; }
            if (choice == 3)
                cout << "Title: " << it->title << "\nAuthor: " << it->author
                     << "\nAvailable copies: " << it->available << '\n';
            else if (choice == 4) {
                if (it->available == 0) cout << "No copies available.\n";
                else { --it->available; saveBooks(books); cout << "Book issued.\n"; }
            } else if (choice == 5) {
                ++it->available; saveBooks(books); cout << "Book returned.\n";
            } else {
                if (it->available == 0) { cout << "Cannot delete: no copies available (possibly issued).\n"; continue; }
                books.erase(it); saveBooks(books); cout << "Book deleted.\n";
            }
        } else if (choice != 0) cout << "Invalid choice.\n";
    } while (choice != 0);
    cout << "Thank you for using the Library Management System.\n";
    return 0;
}
