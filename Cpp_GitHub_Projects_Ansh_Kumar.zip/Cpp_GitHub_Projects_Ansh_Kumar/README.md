# C++ Mini Projects – GitHub Portfolio

**Author:** ANSH KUMAR  
**Admission No.:** 24SCSE1040723  
**Language:** C++ (C++17)

This repository contains four beginner-friendly, menu-driven C++ projects:

1. **Student Management System** – add, display, search, update and delete student records.
2. **Bank Management Application** – create accounts, view balances, deposit, withdraw and close accounts.
3. **Library Management System** – add, list, search, issue, return and delete books.
4. **Tic Tac Toe** – two-player console game with win/draw detection and replay.

## Requirements
- A C++ compiler supporting C++17 (GCC, Clang, or MSVC).
- A terminal or command prompt.

## Folder structure
```text
Cpp_GitHub_Projects/
├── README.md
├── Student_Management_System/
│   └── main.cpp
├── Bank_Management_Application/
│   └── main.cpp
├── Library_Management_System/
│   └── main.cpp
└── Tic_Tac_Toe/
    └── main.cpp
```

## Compile and run

Open a terminal in the project folder. For each project, enter its folder and run:

### Windows (MinGW g++)
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o app.exe
app.exe
```

### Linux / macOS
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o app
./app
```

Repeat these commands inside each project folder.

## Data storage
The Student, Bank and Library applications save their records in local text files (`students.txt`, `accounts.txt`, and `books.txt`) in the current working directory. These files are created automatically after the first successful save. Keep the files with the program to retain records.

## Notes
- These are educational console applications intended for learning C++ structures, vectors, functions, conditionals, loops and file handling.
- The bank project is a classroom demonstration only. It is **not** secure or suitable for real financial transactions.
- Data files are plain text and are not encrypted. Do not store real personal, banking or confidential information.
- For a real deployment, add authentication, input validation, secure storage, backups and proper database transactions.

## Author
**ANSH KUMAR**  
**Admission No.: 24SCSE1040723**
