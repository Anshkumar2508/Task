/*
 Project: Student Management System
 Author: ANSH KUMAR
 Admission No.: 24SCSE1040723
 Language: C++17
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
using namespace std;

struct Student {
    int id;
    string name, course;
    double marks;
};

const string FILE_NAME = "students.txt";

vector<Student> loadStudents() {
    vector<Student> students;
    ifstream in(FILE_NAME);
    Student s;
    while (in >> s.id >> quoted(s.name) >> quoted(s.course) >> s.marks)
        students.push_back(s);
    return students;
}

void saveStudents(const vector<Student>& students) {
    ofstream out(FILE_NAME);
    for (const auto& s : students)
        out << s.id << ' ' << quoted(s.name) << ' ' << quoted(s.course)
            << ' ' << s.marks << '\n';
}

int main() {
    vector<Student> students = loadStudents();
    int choice;
    do {
        cout << "\n===== STUDENT MANAGEMENT SYSTEM =====\n"
             << "1. Add student\n2. Display all students\n3. Search by ID\n"
             << "4. Update student\n5. Delete student\n0. Exit\nChoice: ";
        if (!(cin >> choice)) return 0;

        if (choice == 1) {
            Student s;
            cout << "Student ID: "; cin >> s.id;
            if (any_of(students.begin(), students.end(), [&](const Student& x){ return x.id == s.id; })) {
                cout << "That ID already exists.\n"; continue;
            }
            cin.ignore();
            cout << "Full name: "; getline(cin, s.name);
            cout << "Course: "; getline(cin, s.course);
            cout << "Marks (0-100): "; cin >> s.marks;
            if (s.marks < 0 || s.marks > 100) { cout << "Invalid marks.\n"; continue; }
            students.push_back(s); saveStudents(students);
            cout << "Student added successfully.\n";
        } else if (choice == 2) {
            if (students.empty()) cout << "No student records found.\n";
            else {
                cout << left << setw(10) << "ID" << setw(25) << "NAME" << setw(20) << "COURSE" << "MARKS\n";
                for (const auto& s : students)
                    cout << left << setw(10) << s.id << setw(25) << s.name
                         << setw(20) << s.course << fixed << setprecision(2) << s.marks << '\n';
            }
        } else if (choice == 3 || choice == 4 || choice == 5) {
            int id; cout << "Enter student ID: "; cin >> id;
            auto it = find_if(students.begin(), students.end(), [&](const Student& s){ return s.id == id; });
            if (it == students.end()) { cout << "Student not found.\n"; continue; }
            if (choice == 3) {
                cout << "ID: " << it->id << "\nName: " << it->name
                     << "\nCourse: " << it->course << "\nMarks: " << it->marks << '\n';
            } else if (choice == 4) {
                cin.ignore();
                cout << "New full name: "; getline(cin, it->name);
                cout << "New course: "; getline(cin, it->course);
                cout << "New marks: "; cin >> it->marks;
                if (it->marks < 0 || it->marks > 100) { cout << "Invalid marks; update cancelled.\n"; continue; }
                saveStudents(students); cout << "Record updated.\n";
            } else {
                students.erase(it); saveStudents(students); cout << "Record deleted.\n";
            }
        } else if (choice != 0) cout << "Invalid choice.\n";
    } while (choice != 0);
    cout << "Thank you for using the Student Management System.\n";
    return 0;
}
