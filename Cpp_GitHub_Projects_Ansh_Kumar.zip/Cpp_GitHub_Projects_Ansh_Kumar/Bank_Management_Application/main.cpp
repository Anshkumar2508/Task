/*
 Project: Bank Management Application
 Author: ANSH KUMAR
 Admission No.: 24SCSE1040723
 Language: C++17
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <limits>
using namespace std;

struct Account { long long number; string name; double balance; };
const string FILE_NAME = "accounts.txt";

vector<Account> loadAccounts() {
    vector<Account> a; ifstream in(FILE_NAME); Account x;
    while (in >> x.number >> quoted(x.name) >> x.balance) a.push_back(x);
    return a;
}
void saveAccounts(const vector<Account>& a) {
    ofstream out(FILE_NAME);
    for (const auto& x : a) out << x.number << ' ' << quoted(x.name) << ' ' << fixed << setprecision(2) << x.balance << '\n';
}
int main() {
    auto accounts = loadAccounts(); int choice;
    do {
        cout << "\n===== BANK MANAGEMENT APPLICATION =====\n"
             << "1. Create account\n2. View accounts\n3. Check balance\n"
             << "4. Deposit\n5. Withdraw\n6. Close account\n0. Exit\nChoice: ";
        if (!(cin >> choice)) return 0;
        if (choice == 1) {
            Account a;
            cout << "Account number: "; cin >> a.number;
            if (any_of(accounts.begin(), accounts.end(), [&](const Account& x){ return x.number == a.number; })) {
                cout << "Account number already exists.\n"; continue;
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Account holder name: "; getline(cin, a.name);
            cout << "Opening deposit (>= 0): "; cin >> a.balance;
            if (a.balance < 0) { cout << "Invalid amount.\n"; continue; }
            accounts.push_back(a); saveAccounts(accounts); cout << "Account created.\n";
        } else if (choice == 2) {
            if (accounts.empty()) cout << "No accounts available.\n";
            for (const auto& a : accounts)
                cout << "Account: " << a.number << " | Holder: " << a.name
                     << " | Balance: Rs. " << fixed << setprecision(2) << a.balance << '\n';
        } else if (choice >= 3 && choice <= 6) {
            long long number; cout << "Account number: "; cin >> number;
            auto it = find_if(accounts.begin(), accounts.end(), [&](const Account& a){ return a.number == number; });
            if (it == accounts.end()) { cout << "Account not found.\n"; continue; }
            if (choice == 3) cout << "Available balance: Rs. " << fixed << setprecision(2) << it->balance << '\n';
            if (choice == 4 || choice == 5) {
                double amount; cout << "Amount: "; cin >> amount;
                if (amount <= 0) { cout << "Enter an amount greater than zero.\n"; continue; }
                if (choice == 5 && amount > it->balance) { cout << "Insufficient balance.\n"; continue; }
                it->balance += (choice == 4 ? amount : -amount);
                saveAccounts(accounts);
                cout << (choice == 4 ? "Deposit" : "Withdrawal") << " successful. New balance: Rs. "
                     << fixed << setprecision(2) << it->balance << '\n';
            }
            if (choice == 6) {
                cout << "Close this account? (1=yes, 0=no): "; int confirm; cin >> confirm;
                if (confirm == 1) { accounts.erase(it); saveAccounts(accounts); cout << "Account closed.\n"; }
            }
        } else if (choice != 0) cout << "Invalid choice.\n";
    } while (choice != 0);
    cout << "Thank you. This is an educational demo, not real banking software.\n";
    return 0;
}
